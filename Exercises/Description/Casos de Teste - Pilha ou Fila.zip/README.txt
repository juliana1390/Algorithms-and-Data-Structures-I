Arquivo zip gerado em: 22/10/2022 14:50:03 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Pila ou Filha